<html>
<head>
    <link rel="stylesheet" href="<?= $GLOBALS['css_header'] ?>" type="text/css">
    <title>User Patient Permissions</title>
</head>

<body>

<?php echo $this->content; ?>


</body>

</html>
