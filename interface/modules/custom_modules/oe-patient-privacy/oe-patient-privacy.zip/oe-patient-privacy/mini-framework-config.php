<?php
return [
  'APP_NAMESPACE' => 'PatientPrivacy',

];
